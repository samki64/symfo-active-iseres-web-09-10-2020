<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home_page/index.html.twig */
class __TwigTemplate_67b3327cacd0d0698ecca5aee2ff46c9a805648d0f75a8fa4d05d39a396542b3 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home_page/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home_page/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "home_page/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Projet symfo";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div class=\"container\" style=\"margin-top:30px\">
    <div class=\"row\">
      <div class=\"col-sm-2\">
      </div> 
          <div class=\"col-sm-8\">
          <div class=\"home\" style=\"margin-bottom:0\">
            <h2>Bienvenue sur la page de gestion des fonctionnalités de l'entreprise</h2>
            <span class=\"badge badge-pill badge-info\">Clients</span>
            <span class=\"badge badge-pill badge-info\">Contacts</span>
            <span class=\"badge badge-pill badge-info\">Projets</span>
            <span class=\"badge badge-pill badge-info\">Documents</span>
            <h2>Autres</h2>
            <span class=\"badge badge-pill badge-info\">Fonctions</span>
            <span class=\"badge badge-pill badge-info\">Activités</span>
          </div>
        </div> 
        <div class=\"col-sm-2\">
        </div> 
      </div> 
    </div>

    <div class=\"container\" style=\"margin-top:30px\">
      <div class=\"row\">
        <div class=\"col-sm-4\">
        </div> 
        <div class=\"col-sm-4\">

          <p><a class='btn btn-primary' href=\"vues/gestion_de_projet.php\"><span class='glyphicon glyphicon-list'></span> Fonction gestion de projet</a></p>

          <p><a class='btn btn-primary' href=\"vues/Service_commercial.php\"><span class='glyphicon glyphicon-list'></span> Fonction gestion commerciale</a></p> 

          <p><a class='btn btn-primary' href=\"vues/ressources_humaines.php\"><span class='glyphicon glyphicon-list'></span> Fonction ressources humaines</a></p> 
               
        </div>  
      </div>
    </div>
  </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "home_page/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Projet symfo{% endblock %}

{% block body %}
<div class=\"container\" style=\"margin-top:30px\">
    <div class=\"row\">
      <div class=\"col-sm-2\">
      </div> 
          <div class=\"col-sm-8\">
          <div class=\"home\" style=\"margin-bottom:0\">
            <h2>Bienvenue sur la page de gestion des fonctionnalités de l'entreprise</h2>
            <span class=\"badge badge-pill badge-info\">Clients</span>
            <span class=\"badge badge-pill badge-info\">Contacts</span>
            <span class=\"badge badge-pill badge-info\">Projets</span>
            <span class=\"badge badge-pill badge-info\">Documents</span>
            <h2>Autres</h2>
            <span class=\"badge badge-pill badge-info\">Fonctions</span>
            <span class=\"badge badge-pill badge-info\">Activités</span>
          </div>
        </div> 
        <div class=\"col-sm-2\">
        </div> 
      </div> 
    </div>

    <div class=\"container\" style=\"margin-top:30px\">
      <div class=\"row\">
        <div class=\"col-sm-4\">
        </div> 
        <div class=\"col-sm-4\">

          <p><a class='btn btn-primary' href=\"vues/gestion_de_projet.php\"><span class='glyphicon glyphicon-list'></span> Fonction gestion de projet</a></p>

          <p><a class='btn btn-primary' href=\"vues/Service_commercial.php\"><span class='glyphicon glyphicon-list'></span> Fonction gestion commerciale</a></p> 

          <p><a class='btn btn-primary' href=\"vues/ressources_humaines.php\"><span class='glyphicon glyphicon-list'></span> Fonction ressources humaines</a></p> 
               
        </div>  
      </div>
    </div>
  </div>
{% endblock %}
", "home_page/index.html.twig", "C:\\wamp\\www\\symfo-active-iseres-web-09-10-2020\\templates\\home_page\\index.html.twig");
    }
}
