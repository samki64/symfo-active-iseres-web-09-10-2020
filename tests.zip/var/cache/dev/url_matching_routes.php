<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/clients' => [[['_route' => 'clients_index', '_controller' => 'App\\Controller\\ClientsController::index'], null, ['GET' => 0], null, true, false, null]],
        '/clients/new' => [[['_route' => 'clients_new', '_controller' => 'App\\Controller\\ClientsController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/contacts' => [[['_route' => 'contacts_index', '_controller' => 'App\\Controller\\ContactsController::index'], null, ['GET' => 0], null, true, false, null]],
        '/contacts/new' => [[['_route' => 'contacts_new', '_controller' => 'App\\Controller\\ContactsController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/documents' => [[['_route' => 'documents_index', '_controller' => 'App\\Controller\\DocumentsController::index'], null, ['GET' => 0], null, true, false, null]],
        '/documents/new' => [[['_route' => 'documents_new', '_controller' => 'App\\Controller\\DocumentsController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/' => [[['_route' => 'home_page', '_controller' => 'App\\Controller\\HomePageController::index'], null, null, null, false, false, null]],
        '/accueil' => [[['_route' => 'accueil', '_controller' => 'App\\Controller\\HomePageController::accueil'], null, null, null, false, false, null]],
        '/qui_sommes_nous' => [[['_route' => 'qui_sommes_nous', '_controller' => 'App\\Controller\\HomePageController::qui_sommes_nous'], null, null, null, false, false, null]],
        '/projets' => [[['_route' => 'projets_index', '_controller' => 'App\\Controller\\ProjetsController::index'], null, ['GET' => 0], null, true, false, null]],
        '/projets/new' => [[['_route' => 'projets_new', '_controller' => 'App\\Controller\\ProjetsController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/inscription' => [[['_route' => 'security_registration', '_controller' => 'App\\Controller\\SecurityController::registration'], null, null, null, false, false, null]],
        '/connexion' => [[['_route' => 'security_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/deconnexion' => [[['_route' => 'security_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/c(?'
                    .'|lients/([^/]++)(?'
                        .'|(*:192)'
                        .'|/edit(*:205)'
                        .'|(*:213)'
                    .')'
                    .'|ontacts/([^/]++)(?'
                        .'|(*:241)'
                        .'|/edit(*:254)'
                        .'|(*:262)'
                    .')'
                .')'
                .'|/documents/([^/]++)(?'
                    .'|(*:294)'
                    .'|/edit(*:307)'
                    .'|(*:315)'
                .')'
                .'|/projets/([^/]++)(?'
                    .'|(*:344)'
                    .'|/edit(*:357)'
                    .'|(*:365)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        192 => [[['_route' => 'clients_show', '_controller' => 'App\\Controller\\ClientsController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        205 => [[['_route' => 'clients_edit', '_controller' => 'App\\Controller\\ClientsController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        213 => [[['_route' => 'clients_delete', '_controller' => 'App\\Controller\\ClientsController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        241 => [[['_route' => 'contacts_show', '_controller' => 'App\\Controller\\ContactsController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        254 => [[['_route' => 'contacts_edit', '_controller' => 'App\\Controller\\ContactsController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        262 => [[['_route' => 'contacts_delete', '_controller' => 'App\\Controller\\ContactsController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        294 => [[['_route' => 'documents_show', '_controller' => 'App\\Controller\\DocumentsController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        307 => [[['_route' => 'documents_edit', '_controller' => 'App\\Controller\\DocumentsController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        315 => [[['_route' => 'documents_delete', '_controller' => 'App\\Controller\\DocumentsController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        344 => [[['_route' => 'projets_show', '_controller' => 'App\\Controller\\ProjetsController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        357 => [[['_route' => 'projets_edit', '_controller' => 'App\\Controller\\ProjetsController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        365 => [
            [['_route' => 'projets_delete', '_controller' => 'App\\Controller\\ProjetsController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
