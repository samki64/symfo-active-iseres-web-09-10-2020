<?php

namespace App\DataFixtures;

use App\Entity\Clients;
use App\Entity\Projets;
use App\Entity\Contacts;
use App\Entity\Documents;
use App\Entity\Fonctions;
use App\Entity\SecteurActivite;
use Doctrine\Persistence\ObjectManager;
use Doctrine\Bundle\FixturesBundle\Fixture;

class ClientFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        $faker = \Faker\Factory::create('fr_FR');

        for($k = 1; $k < 10; $k++){
            $activite = new SecteurActivite();

            $activite->setACtivite($faker->word);

        $manager->persist($activite);
        }

        for ($j = 1; $j <= 10 ; $j++) {
            $client = new Clients();
            $secteurActivite = new SecteurActivite;

            $content = '</p>' . join($faker->paragraphs(2), '</p><p>') . '</p>';

            $client->setRaisonSociale($faker->company)
                     ->setAdresseClient($faker->streetAddress)
                     ->setCodePostalClient($faker->buildingNumber)
                     ->setVilleClient($faker->city)
                     ->setChiffreAffaire($faker->randomNumber($nbDigits = NULL, $strict = false))
                     ->setEffectif($faker->numberBetween($min = 10, $max = 100))
                     ->setTelephoneClient($faker->phoneNumber)
                     ->setTypeClient($faker->word )
                     ->setNatureClient($faker->word )
                     ->setCommentaireClient($content )
                     ->setSecteurActivite($activite);
                    
            $manager->persist($client);

            for($i = 1; $i < 10; $i++){
                $projet = new Projets();

                $projet->setAbregeProjet($faker->word)
                    ->setNomProjet($faker->sentence($nbWords = 4, $variableNbWords = true))
                    ->setTypeProjet($faker->word);

            $manager->persist($projet);
            }

            for($m = 1; $m < 10; $m++){
                $fonction = new Fonctions();

                $fonction->setFonction($faker->word);

            $manager->persist($fonction);
            }

            for ($l = 1; $l <= 7 ; $l++) {
                $contact = new Contacts();
                // $fonction = new Fonctions;
                $contact->setNomContact($faker->firstName)
                         ->setPrenomContact($faker->lastName)
                         ->setTelephoneContact($faker->phoneNumber)                         
                         ->setEmailContact($faker->email)
                         ->setDuree($faker->randomDigit)
                         ->setClient($client)
                         ->setFonction($fonction);
    
                $manager->persist($contact);
            }

            for($n = 1; $n < 10; $n++){
                $document = new Documents();
                // $days = (new \DateTime())->diff($document->getDateEdition())->days;

                $document->setTitre($faker->word)
                    ->setResume($faker->sentence($nbWords = 4, $variableNbWords = true))
                    ->setDateEdition($faker->dateTimeBetween('-6 months'))
                    ->setContact($contact);

            $manager->persist($document);
            }

        }

        $manager->flush();
    }
}
