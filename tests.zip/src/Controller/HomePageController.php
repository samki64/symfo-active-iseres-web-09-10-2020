<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class HomePageController extends AbstractController
{
    /**
     * @Route("/", name="home_page")
     */
    public function index()
    {
        return $this->render('home_page/index.html.twig', [
            'controller_name' => 'HomePageController',
        ]);
    }

    /**
     * @Route("/accueil", name="accueil")
     */
    public function accueil()
    {
        return $this->render('home_page/accueil.html.twig', [
            'controller_name' => 'HomePageController',
        ]);
    }

    /**
     * @Route("/qui_sommes_nous", name="qui_sommes_nous")
     */
    public function qui_sommes_nous()
    {
        return $this->render('home_page/qui_sommes_nous.html.twig', [
            'controller_name' => 'HomePageController',
        ]);
    }
}
