<?php

namespace App\Form;

use App\Entity\Clients;
use App\Entity\Projets;
use App\Entity\SecteurActivite;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ClientsType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('raisonSociale')
            ->add('adresseClient')
            ->add('codePostalClient')
            ->add('villeClient')
            ->add('chiffreAffaire')
            ->add('effectif')
            ->add('telephoneClient')
            ->add('typeClient')
            ->add('natureClient')
            ->add('commentaireClient')
            ->add('secteurActivite', EntityType::class, [
                'class' => SecteurActivite::class,
                'choice_label' => 'activite'
        ])
            // ->add('projet')
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Clients::class,
        ]);
    }
}
