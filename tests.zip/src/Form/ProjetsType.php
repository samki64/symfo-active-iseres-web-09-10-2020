<?php

namespace App\Form;

use App\Entity\Clients;
use App\Entity\Projets;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ProjetsType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('abregeProjet')
            ->add('nomProjet')
            ->add('typeProjet')
            // ->add('clients', EntityType::class, [
            //     'class' => Clients::class,
            //     'choice_label' => 'raisonSociale'])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Projets::class,
        ]);
    }
}
