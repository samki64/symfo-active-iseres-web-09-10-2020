<?php

namespace App\Form;

use App\Entity\Clients;
use App\Entity\Contacts;
use App\Entity\Fonctions;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ContactsType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nomContact')
            ->add('prenomContact')
            ->add('telephoneContact')
            ->add('emailContact')
            ->add('duree')
            ->add('client', EntityType::class, [
                'class' => Clients::class,
                'choice_label' => 'raisonSociale'
        ])
            ->add('fonction', EntityType::class, [
                'class' => Fonctions::class,
                'choice_label' => 'fonction'
        ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Contacts::class,
        ]);
    }
}
