<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20201009132029 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE clients (id INT AUTO_INCREMENT NOT NULL, secteur_activite_id INT NOT NULL, raison_sociale VARCHAR(255) NOT NULL, adresse_client VARCHAR(255) NOT NULL, code_postal_client INT NOT NULL, ville_client VARCHAR(255) NOT NULL, chiffre_affaire VARCHAR(255) NOT NULL, effectif INT NOT NULL, telephone_client VARCHAR(255) NOT NULL, type_client VARCHAR(255) NOT NULL, nature_client VARCHAR(255) NOT NULL, commentaire_client LONGTEXT NOT NULL, INDEX IDX_C82E745233A7FC (secteur_activite_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE clients_projets (clients_id INT NOT NULL, projets_id INT NOT NULL, INDEX IDX_8A3F61D4AB014612 (clients_id), INDEX IDX_8A3F61D4597A6CB7 (projets_id), PRIMARY KEY(clients_id, projets_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE contacts (id INT AUTO_INCREMENT NOT NULL, client_id INT NOT NULL, fonction_id INT NOT NULL, nom_contact VARCHAR(255) NOT NULL, prenom_contact VARCHAR(255) NOT NULL, telephone_contact VARCHAR(255) NOT NULL, email_contact VARCHAR(255) NOT NULL, duree INT NOT NULL, INDEX IDX_3340157319EB6921 (client_id), INDEX IDX_3340157357889920 (fonction_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE documents (id INT AUTO_INCREMENT NOT NULL, contact_id INT NOT NULL, titre VARCHAR(255) NOT NULL, resume VARCHAR(255) NOT NULL, date_edition DATE NOT NULL, INDEX IDX_A2B07288E7A1254A (contact_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE fonctions (id INT AUTO_INCREMENT NOT NULL, fonction VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE projets (id INT AUTO_INCREMENT NOT NULL, abrege_projet VARCHAR(255) NOT NULL, nom_projet VARCHAR(255) NOT NULL, type_projet VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE secteur_activite (id INT AUTO_INCREMENT NOT NULL, activite VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE users (id INT AUTO_INCREMENT NOT NULL, login_user VARCHAR(255) NOT NULL, pass_user VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE clients ADD CONSTRAINT FK_C82E745233A7FC FOREIGN KEY (secteur_activite_id) REFERENCES secteur_activite (id)');
        $this->addSql('ALTER TABLE clients_projets ADD CONSTRAINT FK_8A3F61D4AB014612 FOREIGN KEY (clients_id) REFERENCES clients (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE clients_projets ADD CONSTRAINT FK_8A3F61D4597A6CB7 FOREIGN KEY (projets_id) REFERENCES projets (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE contacts ADD CONSTRAINT FK_3340157319EB6921 FOREIGN KEY (client_id) REFERENCES clients (id)');
        $this->addSql('ALTER TABLE contacts ADD CONSTRAINT FK_3340157357889920 FOREIGN KEY (fonction_id) REFERENCES fonctions (id)');
        $this->addSql('ALTER TABLE documents ADD CONSTRAINT FK_A2B07288E7A1254A FOREIGN KEY (contact_id) REFERENCES contacts (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE clients_projets DROP FOREIGN KEY FK_8A3F61D4AB014612');
        $this->addSql('ALTER TABLE contacts DROP FOREIGN KEY FK_3340157319EB6921');
        $this->addSql('ALTER TABLE documents DROP FOREIGN KEY FK_A2B07288E7A1254A');
        $this->addSql('ALTER TABLE contacts DROP FOREIGN KEY FK_3340157357889920');
        $this->addSql('ALTER TABLE clients_projets DROP FOREIGN KEY FK_8A3F61D4597A6CB7');
        $this->addSql('ALTER TABLE clients DROP FOREIGN KEY FK_C82E745233A7FC');
        $this->addSql('DROP TABLE clients');
        $this->addSql('DROP TABLE clients_projets');
        $this->addSql('DROP TABLE contacts');
        $this->addSql('DROP TABLE documents');
        $this->addSql('DROP TABLE fonctions');
        $this->addSql('DROP TABLE projets');
        $this->addSql('DROP TABLE secteur_activite');
        $this->addSql('DROP TABLE users');
    }
}
